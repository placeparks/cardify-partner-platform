import { createServer } from 'node:http'
import { createHmac, timingSafeEqual } from 'node:crypto'
import { ReceiverStore, verifySignature } from './receiver-store.mjs'
const secret = process.env.TCGP_TEST_WEBHOOK_SECRET
const token = process.env.SMOKE_RECEIVER_TOKEN
if (!secret || !token || token.length < 32) throw new Error('Set Test webhook signing secret and a >=32-character receiver control token')
const store = new ReceiverStore(process.env.SMOKE_RECEIVER_DB || 'smoke-receiver.sqlite')
const port = Number(process.env.PORT || 8788)
const equal = (a, b) => { const x = Buffer.from(a), y = Buffer.from(b); return x.length === y.length && timingSafeEqual(x, y) }
const server = createServer(async (req, res) => {
  const reply = (status, body) => { res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(body)) }
  try {
    const path = new URL(req.url, 'http://receiver.local').pathname
    if (path !== '/webhooks/tcgplaytest' && !equal(req.headers.authorization || '', 'Bearer ' + token)) return reply(401, { error: 'Unauthorized' })
    const chunks = []; let bytes = 0
    for await (const part of req) { bytes += part.length; if (bytes > 512000) return reply(413, { error: 'Too large' }); chunks.push(part) }
    const raw = Buffer.concat(chunks)
    if (path === '/webhooks/tcgplaytest' && req.method === 'POST') {
      if (!verifySignature(raw, req.headers['tcgp-signature'], secret)) return reply(401, { error: 'Invalid signature' })
      const outcome = store.accept(raw.toString('utf8'))
      console.log(JSON.stringify({ event: 'smoke_webhook_received', status: outcome.status, signature_verified: true }))
      return reply(outcome.status, { received: outcome.status === 200 })
    }
    if (path === '/runs' && req.method === 'POST') {
      const input = JSON.parse(raw); store.register(input.external_ref, input.fail_first === true)
      return reply(201, { registered: true })
    }
    const match = /^\/runs\/(deploy-smoke-[a-f0-9-]{36})(\/replay)?$/.exec(path)
    if (match && !match[2] && req.method === 'GET') return reply(200, store.state(match[1]))
    if (match?.[2] && req.method === 'POST') {
      const body = store.replayBody(match[1]); if (!body) return reply(409, { error: 'No real delivered paid event to replay' })
      const timestamp = Math.floor(Date.now() / 1000)
      const mac = createHmac('sha256', secret).update(`${timestamp}.${body}`).digest('hex')
      const responses = await Promise.all(Array.from({ length: 3 }, () => fetch(`http://127.0.0.1:${port}/webhooks/tcgplaytest`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'TCGP-Signature': `t=${timestamp},v1=${mac}` }, body,
        signal: AbortSignal.timeout(5000),
      })))
      return reply(responses.every(r => r.status === 200) ? 200 : 500, { replayed: responses.length })
    }
    reply(404, { error: 'Not found' })
  } catch { reply(500, { error: 'Receiver failed' }) }
})
server.requestTimeout = 15000
server.listen(port, '127.0.0.1', () => console.log(`Sandbox-only receiver listening on 127.0.0.1:${port}; expose through HTTPS on your registered website origin.`))
