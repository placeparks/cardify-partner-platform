import { checkSandbox } from './sandbox.mjs'
try {
  const result = await checkSandbox(process.env, evidence => console.log(JSON.stringify(evidence, null, 2)))
  console.log('PASS — actual signed delivery, worker retry, duplicate protection and test order state verified.')
  console.log(JSON.stringify(result, null, 2))
} catch (error) {
  console.error('FAIL — ' + error.message)
  process.exitCode = 1
}
