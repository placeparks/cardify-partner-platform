import { DatabaseSync } from 'node:sqlite'
import { createHmac, timingSafeEqual } from 'node:crypto'

export function verifySignature(raw, signature, secret, now = Date.now()) {
  const parts = /^t=(\d+),v1=([a-f0-9]{64})$/.exec(signature || '')
  if (!parts || Math.abs(Math.floor(now / 1000) - Number(parts[1])) > 300) return false
  const expected = createHmac('sha256', secret).update(parts[1] + '.').update(raw).digest()
  return timingSafeEqual(expected, Buffer.from(parts[2], 'hex'))
}

// Dedicated sandbox receiver only. One durable database file per receiver instance.
export class ReceiverStore {
  constructor(file) {
    this.db = new DatabaseSync(file)
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;
      CREATE TABLE IF NOT EXISTS runs (ref TEXT PRIMARY KEY, created INTEGER NOT NULL, fail_first INTEGER NOT NULL, order_id TEXT, status TEXT, updates INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS events (id TEXT PRIMARY KEY, ref TEXT NOT NULL, raw TEXT NOT NULL, status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, applied INTEGER NOT NULL DEFAULT 0, duplicates INTEGER NOT NULL DEFAULT 0);`)
  }
  register(ref, failFirst) {
    if (!/^deploy-smoke-[a-f0-9-]{36}$/.test(ref)) throw new Error('Invalid smoke run reference')
    this.db.prepare('INSERT INTO runs(ref,created,fail_first) VALUES(?,?,?)').run(ref, Date.now(), failFirst ? 1 : 0)
  }
  accept(raw) {
    const event = JSON.parse(raw)
    const d = event.data
    if (d?.mode !== 'test' || d?.simulated !== true || !/^test_order_[a-f0-9]{32}$/.test(d.id || '') ||
      !/^cart_[a-f0-9]{64}$/.test(d.cart_id || '') || !['paid', 'in_production', 'shipped', 'cancelled'].includes(d.status) ||
      event.type !== 'order.' + d.status || typeof event.id !== 'string' || event.id.length > 200) return { status: 422 }
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const run = this.db.prepare('SELECT * FROM runs WHERE ref=?').get(d.external_ref)
      if (!run || Date.now() - run.created > 86400000 || (run.order_id && run.order_id !== d.id)) { this.db.exec('ROLLBACK'); return { status: 422 } }
      const existing = this.db.prepare('SELECT * FROM events WHERE id=?').get(event.id)
      if (existing && existing.raw !== raw) { this.db.exec('ROLLBACK'); return { status: 409 } }
      this.db.prepare('INSERT OR IGNORE INTO events(id,ref,raw,status) VALUES(?,?,?,?)').run(event.id, d.external_ref, raw, d.status)
      this.db.prepare('UPDATE events SET attempts=attempts+1 WHERE id=?').run(event.id)
      this.db.prepare('UPDATE runs SET order_id=? WHERE ref=?').run(d.id, d.external_ref)
      if (run.fail_first && !existing && d.status === 'paid') { this.db.exec('COMMIT'); return { status: 503, reason: 'intentional_retry_test' } }
      if (existing?.applied) {
        this.db.prepare('UPDATE events SET duplicates=duplicates+1 WHERE id=?').run(event.id)
      } else {
        this.db.prepare('UPDATE events SET applied=1 WHERE id=?').run(event.id)
        const ranks = { paid: 1, in_production: 2, cancelled: 3, shipped: 4 }
        // Never regress a later test state when deliveries arrive out of order.
        if ((ranks[d.status] || 0) > (ranks[run.status] || 0)) this.db.prepare('UPDATE runs SET status=?,updates=updates+1 WHERE ref=?').run(d.status, d.external_ref)
      }
      this.db.exec('COMMIT')
      return { status: 200 }
    } catch (e) { this.db.exec('ROLLBACK'); throw e }
  }
  state(ref) {
    const run = this.db.prepare('SELECT ref,order_id,status,updates FROM runs WHERE ref=?').get(ref)
    if (!run) return null
    return { ...run, events: this.db.prepare('SELECT id,status,attempts,applied,duplicates FROM events WHERE ref=? ORDER BY rowid').all(ref) }
  }
  replayBody(ref) { return this.db.prepare('SELECT raw FROM events WHERE ref=? AND status=\'paid\' AND applied=1').get(ref)?.raw }
  close() { this.db.close() }
}
