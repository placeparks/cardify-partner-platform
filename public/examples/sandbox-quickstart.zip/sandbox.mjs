import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { createHash, randomUUID } from 'node:crypto'
import { httpsOrigin, jsonRequest, until } from './http.mjs'

export async function checkSandbox(env = process.env, observe = () => {}) {
  const base = httpsOrigin(env.SMOKE_PARTNER_ORIGIN)
  assert.match(env.SMOKE_TEST_API_KEY || '', /^tcgp_test_[a-f0-9]{64}$/, 'Dedicated TEST API key required')
  const receiver = httpsOrigin(env.SMOKE_RECEIVER_ORIGIN)
  assert.ok(env.SMOKE_RECEIVER_TOKEN?.length >= 32, 'Receiver control token required')
  const headers = { Authorization: 'Bearer ' + env.SMOKE_TEST_API_KEY }
  const receiverHeaders = { Authorization: 'Bearer ' + env.SMOKE_RECEIVER_TOKEN }
  const ref = 'deploy-smoke-' + randomUUID()
  const api = (path, body, extra = {}) => jsonRequest(base + path, { body, headers: { ...headers, ...extra } })
  const control = (path, body) => jsonRequest(receiver + path, { body, headers: receiverHeaders })
  await control('/runs', { external_ref: ref, fail_first: true })
  const bytes = await readFile(new URL('./dummy-front.png', import.meta.url))
  const grant = await api('/v1/uploads', { content_type: 'image/png', size: bytes.length })
  const destination = new URL(grant.upload_url)
  assert.ok(destination.protocol === 'https:' && !destination.username && !destination.password, 'Expected HTTPS storage grant')
  assert.equal(grant.method, 'PUT')
  const uploaded = await fetch(destination, { method: 'PUT', headers: grant.headers, body: bytes, redirect: 'error', signal: AbortSignal.timeout(45000) })
  assert.ok(uploaded.ok, 'Artwork upload failed')
  const created = await api('/v1/carts', { external_ref: ref, items: [{ image_url: grant.image_url,
    sha256: createHash('sha256').update(bytes).digest('hex'), quantity: 1 }] }, { 'Idempotency-Key': ref })
  assert.equal(created.mode, 'test', 'Refusing any live completion')
  const cart = await until(() => api('/v1/carts/' + created.id), c => c.status !== 'validating')
  assert.equal(cart.mode, 'test'); assert.equal(cart.status, 'open')
  const order = await api('/v1/test/carts/' + cart.id + '/complete', { confirm_simulation: true })
  assert.match(order.id, /^test_order_[a-f0-9]{32}$/)
  assert.equal(order.simulated, true); assert.equal(order.mode, 'test'); assert.equal(order.status, 'paid')
  observe({ step: 'sandbox_completed', cart_id: cart.id, order_id: order.id, external_ref: ref })
  const state = () => control('/runs/' + ref)
  // Wait for the actual maintenance worker to retry its intentionally rejected first delivery.
  const paid = await until(state, s => s?.status === 'paid' && s.events.some(e => e.status === 'paid' && e.attempts >= 2 && e.applied === 1), Number(env.SMOKE_WEBHOOK_TIMEOUT_MS || 600000), 5000)
  assert.equal(paid.order_id, order.id); assert.equal(paid.updates, 1)
  observe({ step: 'signed_webhook_delivered_after_retry', receiver: paid })
  const duplicate = await api('/v1/test/carts/' + cart.id + '/complete', { confirm_simulation: true })
  assert.equal(duplicate.id, order.id)
  await control('/runs/' + ref + '/replay', {})
  const repeated = await state()
  assert.equal(repeated.updates, 1)
  assert.equal(repeated.events.filter(e => e.status === 'paid').length, 1)
  assert.ok(repeated.events[0].duplicates >= 3 && repeated.events[0].applied === 1, 'Duplicate webhook processing detected')
  const invalid = await fetch(receiver + '/webhooks/tcgplaytest', { method: 'POST', headers: { 'Content-Type': 'application/json', 'TCGP-Signature': 't=1,v1=' + '0'.repeat(64) }, body: '{}', redirect: 'manual', signal: AbortSignal.timeout(30000) })
  assert.equal(invalid.status, 401, 'Receiver must reject invalid signatures')
  assert.deepEqual(await state(), repeated, 'Invalid signature changed receiver state')
  for (const status of ['in_production', 'shipped']) {
    await api('/v1/test/orders/' + order.id + '/events', { status })
    await until(state, s => s?.status === status, Number(env.SMOKE_WEBHOOK_TIMEOUT_MS || 600000), 5000)
  }
  const final = await state()
  assert.equal(final.updates, 3)
  assert.equal(final.events.length, 3)
  assert.ok(final.events.every(e => e.applied === 1))
  const verified = await api('/v1/orders/' + order.id)
  assert.equal(verified.status, 'shipped'); assert.equal(verified.mode, 'test')
  assert.equal((await api('/v1/carts/' + cart.id)).status, 'converted')
  return { cart_id: cart.id, order_id: order.id, external_ref: ref, receiver: final, invalid_signature_status: invalid.status,
    payment_attempted: false, actual_worker_retry_verified: true, duplicate_events_applied_once: true }
}
