import assert from 'node:assert/strict'
export const pause = ms => new Promise(resolve => setTimeout(resolve, ms))
export function httpsOrigin(value) {
  const u = new URL(value)
  assert.ok(u.protocol === 'https:' && !u.username && !u.password && u.pathname === '/' && !u.search && !u.hash, 'Expected exact HTTPS origin')
  return u.origin
}
export async function jsonRequest(url, { body, headers = {}, method, expected } = {}) {
  const r = await fetch(url, { method: method || (body === undefined ? 'GET' : 'POST'),
    headers: { ...headers, ...(body === undefined ? {} : { 'Content-Type': 'application/json' }) },
    body: body === undefined ? undefined : JSON.stringify(body), redirect: 'manual', signal: AbortSignal.timeout(45000) })
  assert.ok(expected ? expected.includes(r.status) : r.ok, `HTTP ${r.status} from ${new URL(url).pathname.replace(/(?:cart_|test_order_)[a-f0-9]+|[a-f0-9]{64}/g, '[id]')}`)
  return r.status === 204 ? null : r.json()
}
export async function until(work, predicate, timeout = 180000, interval = 4000) {
  const deadline = Date.now() + timeout
  do { const result = await work(); if (predicate(result)) return result; await pause(interval) } while (Date.now() < deadline)
  throw new Error('Timed out waiting for verified state; queued is not a pass')
}
